/*
  Servicio.java
  Servicio web REST (Usuarios + Artículos + Carrito)
  Extendido para Tarea 7 - Sistemas Distribuidos
  Carlos Pineda Guerrero. 2025 (con extensiones para el prototipo e-commerce)
*/

package servicio;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import java.sql.*;
import javax.sql.DataSource;
import javax.naming.Context;
import javax.naming.InitialContext;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.security.SecureRandom;

import com.fasterxml.jackson.databind.ObjectMapper;

@Path("ws")
public class Servicio extends Application
{
  static DataSource pool = null;
  static
  {
    try
    {
      Context ctx = new InitialContext();
      pool = (DataSource)ctx.lookup("java:comp/env/jdbc/datasource_Servicio");
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  static ObjectMapper j = new ObjectMapper()
    .setDateFormat(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS"));

  static final String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  static final SecureRandom random = new SecureRandom();

  static String generarToken(int longitud)
  {
    StringBuilder sb = new StringBuilder(longitud);
    for (int i = 0; i < longitud; i++)
      sb.append(caracteres.charAt(random.nextInt(caracteres.length())));
    return sb.toString();
  }

  boolean verifica_acceso(Connection conexion,String email,String token) throws Exception
  {
    PreparedStatement stmt_1 = conexion.prepareStatement("SELECT 1 FROM usuarios WHERE email=? and token=?");
    try
    {
      stmt_1.setString(1,email);
      stmt_1.setString(2,token);
      ResultSet rs = stmt_1.executeQuery();
      try
      {
        return rs.next();
      }
      finally
      { rs.close(); }
    }
    finally
    { stmt_1.close(); }
  }

  boolean verifica_acceso(Connection conexion,int id_usuario,String token) throws Exception
  {
    PreparedStatement stmt_1 = conexion.prepareStatement("SELECT 1 FROM usuarios WHERE id_usuario=? and token=?");
    try
    {
      stmt_1.setInt(1,id_usuario);
      stmt_1.setString(2,token);
      ResultSet rs = stmt_1.executeQuery();
      try
      {
        return rs.next();
      }
      finally
      { rs.close(); }
    }
    finally
    { stmt_1.close(); }
  }

  // ------------------ LOGIN ------------------
  @GET
  @Path("login")
  @Produces(MediaType.APPLICATION_JSON)
  public Response login(@QueryParam("email") String email,@QueryParam("password") String password) throws Exception
  {
    Connection conexion= pool.getConnection();
    try
    {
      PreparedStatement stmt_1 = conexion.prepareStatement("SELECT id_usuario FROM usuarios WHERE email=? and password=?");
      try
      {
        stmt_1.setString(1,email);
        stmt_1.setString(2,password);
        ResultSet rs = stmt_1.executeQuery();
        try
        {
          if (rs.next())
          {
            int id_usuario = rs.getInt(1);
            String token = generarToken(20);

            PreparedStatement stmt_2 = conexion.prepareStatement("UPDATE usuarios SET token=? WHERE email=?");
            try
            {
              stmt_2.setString(1,token);
              stmt_2.setString(2,email);
              stmt_2.executeUpdate();
            }
            finally
            { stmt_2.close(); }

            return Response.ok("{\"token\":\"" + token + "\",\"id_usuario\":" + id_usuario + "}").build();
          }
          return Response.status(400).entity(j.writeValueAsString(new HuboError("Acceso denegado"))).build();
        }
        finally
        { rs.close(); }
      }
      finally
      { stmt_1.close(); }
    }
    catch (Exception e)
    {
      return Response.status(400).entity(j.writeValueAsString(new HuboError(e.getMessage()))).build();
    }
    finally
    { conexion.close(); }
  }

  // ------------------ USUARIOS: ALTA ------------------
  @POST
  @Path("alta_usuario")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public Response alta(Usuario usuario) throws Exception
  {
    Connection conexion = pool.getConnection();
    int id_usuario = 0;

    if (usuario.email == null || usuario.email.equals(""))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Se debe ingresar el email"))).build();
    if (usuario.password == null || usuario.password.equals(""))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Se debe ingresar la contraseña"))).build();
    if (usuario.nombre == null || usuario.nombre.equals(""))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Se debe ingresar el nombre"))).build();
    if (usuario.apellido_paterno == null || usuario.apellido_paterno.equals(""))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Se debe ingresar el apellido paterno"))).build();
    if (usuario.fecha_nacimiento == null)
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Se debe ingresar la fecha de nacimiento"))).build();

    try
    {
      conexion.setAutoCommit(false);

      PreparedStatement stmt_1 = conexion.prepareStatement(
        "INSERT INTO usuarios(id_usuario,email,password,nombre,apellido_paterno,apellido_materno,fecha_nacimiento,telefono,genero) VALUES (0,?,?,?,?,?,?,?,?)",
        Statement.RETURN_GENERATED_KEYS);
      try
      {
        stmt_1.setString(1,usuario.email);
        stmt_1.setString(2,usuario.password);
        stmt_1.setString(3,usuario.nombre);
        stmt_1.setString(4,usuario.apellido_paterno);

        if (usuario.apellido_materno != null)
          stmt_1.setString(5,usuario.apellido_materno);
        else
          stmt_1.setNull(5,Types.VARCHAR);

        stmt_1.setTimestamp(6,usuario.fecha_nacimiento);

        if (usuario.telefono != null)
          stmt_1.setLong(7,usuario.telefono);
        else
          stmt_1.setNull(7,Types.BIGINT);

        if (usuario.genero != null)
          stmt_1.setString(8,usuario.genero);
        else
          stmt_1.setNull(8,Types.CHAR);

        stmt_1.executeUpdate();

        ResultSet rs = stmt_1.getGeneratedKeys();
        try
        {
          if (rs.next())
            id_usuario = rs.getInt(1);
        }
        finally
        { rs.close(); }
      }
      finally
      { stmt_1.close(); }

      if (id_usuario == 0)
        return Response.status(400).entity(j.writeValueAsString(new HuboError("No se pudo obtener el ID del usuario"))).build();

      if (usuario.foto != null)
      {
        PreparedStatement stmt_2 = conexion.prepareStatement("INSERT INTO fotos_usuarios(id_foto,foto,id_usuario) VALUES (0,?,?)");
        try
        {
          stmt_2.setBytes(1,usuario.foto);
          stmt_2.setInt(2,id_usuario);
          stmt_2.executeUpdate();
        }
        finally
        { stmt_2.close(); }
      }
      conexion.commit();
    }
    catch (Exception e)
    {
      conexion.rollback();
      return Response.status(400).entity(j.writeValueAsString(new HuboError(e.getMessage()))).build();
    }
    finally
    {
      conexion.setAutoCommit(true);
      conexion.close();
    }
    return Response.ok("{\"mensaje\":\"Se dio de alta el usuario\"}").build();
  }

  // ------------------ USUARIOS: CONSULTA ------------------
  @GET
  @Path("consulta_usuario")
  @Produces(MediaType.APPLICATION_JSON)
  public Response consulta(@QueryParam("email") String email,@QueryParam("token") String token) throws Exception
  {
    Connection conexion= pool.getConnection();
    if (!verifica_acceso(conexion,email,token))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Acceso denegado"))).build();
    try
    {
      PreparedStatement stmt_1 = conexion.prepareStatement(
        "SELECT a.email,a.nombre,a.apellido_paterno,a.apellido_materno,a.fecha_nacimiento,a.telefono,a.genero,b.foto " +
        "FROM usuarios a LEFT OUTER JOIN fotos_usuarios b ON a.id_usuario=b.id_usuario WHERE email=?");
      try
      {
        stmt_1.setString(1,email);
        ResultSet rs = stmt_1.executeQuery();
        try
        {
          if (rs.next())
          {
            Usuario r = new Usuario();
            r.email = rs.getString(1);
            r.nombre = rs.getString(2);
            r.apellido_paterno = rs.getString(3);
            r.apellido_materno = rs.getString(4);
            r.fecha_nacimiento = rs.getTimestamp(5);
            r.telefono = rs.getObject(6) != null ? rs.getLong(6) : null;
            r.genero = rs.getString(7);
            r.foto = rs.getBytes(8);
            return Response.ok().entity(j.writeValueAsString(r)).build();
          }
          return Response.status(400).entity(j.writeValueAsString(new HuboError("Acceso denegado"))).build();
        }
        finally
        { rs.close(); }
      }
      finally
      { stmt_1.close(); }
    }
    catch (Exception e)
    {
      return Response.status(400).entity(j.writeValueAsString(new HuboError(e.getMessage()))).build();
    }
    finally
    { conexion.close(); }
  }

  // ------------------ USUARIOS: MODIFICA ------------------
  @PUT
  @Path("modifica_usuario")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public Response modifica(@QueryParam("email") String email,@QueryParam("token") String token,Usuario usuario) throws Exception
  {
    Connection conexion= pool.getConnection();
    if (!verifica_acceso(conexion,email,token))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Acceso denegado"))).build();

    if (usuario.nombre == null || usuario.nombre.equals(""))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Se debe ingresar el nombre"))).build();
    if (usuario.apellido_paterno == null || usuario.apellido_paterno.equals(""))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Se debe ingresar el apellido paterno"))).build();
    if (usuario.fecha_nacimiento == null)
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Se debe ingresar la fecha de nacimiento"))).build();

    conexion.setAutoCommit(false);
    try
    {
      PreparedStatement stmt_1 = conexion.prepareStatement(
        "UPDATE usuarios SET nombre=?,apellido_paterno=?,apellido_materno=?,fecha_nacimiento=?,telefono=?,genero=? WHERE email=?");
      try
      {
        stmt_1.setString(1,usuario.nombre);
        stmt_1.setString(2,usuario.apellido_paterno);

        if (usuario.apellido_materno != null)
          stmt_1.setString(3,usuario.apellido_materno);
        else
          stmt_1.setNull(3,Types.VARCHAR);

        stmt_1.setTimestamp(4,usuario.fecha_nacimiento);

        if (usuario.telefono != null)
          stmt_1.setLong(5,usuario.telefono);
        else
          stmt_1.setNull(5,Types.BIGINT);

        if (usuario.genero != null)
          stmt_1.setString(6,usuario.genero);
        else
          stmt_1.setNull(6,Types.CHAR);

        stmt_1.setString(7,email);
        stmt_1.executeUpdate();
      }
      finally
      { stmt_1.close(); }

      if (!usuario.password.equals(""))
      {
        PreparedStatement stmt_2 = conexion.prepareStatement("UPDATE usuarios SET password=? WHERE email=?");
        try
        {
          stmt_2.setString(1,usuario.password);
          stmt_2.setString(2,email);
          stmt_2.executeUpdate();
        }
        finally
        { stmt_2.close(); }
      }

      PreparedStatement stmt_3 = conexion.prepareStatement("DELETE FROM fotos_usuarios WHERE id_usuario=(SELECT id_usuario FROM usuarios WHERE email=?)");
      try
      {
        stmt_3.setString(1,email);
        stmt_3.executeUpdate();
      }
      finally
      { stmt_3.close(); }

      if (usuario.foto != null)
      {
        PreparedStatement stmt_4 = conexion.prepareStatement(
          "INSERT INTO fotos_usuarios(id_foto,foto,id_usuario) VALUES (0,?,(SELECT id_usuario FROM usuarios WHERE email=?))");
        try
        {
          stmt_4.setBytes(1,usuario.foto);
          stmt_4.setString(2,email);
          stmt_4.executeUpdate();
        }
        finally
        { stmt_4.close(); }
      }

      conexion.commit();
      return Response.ok("{\"mensaje\":\"Se modificó el usuario\"}").build();
    }
    catch (Exception e)
    {
      conexion.rollback();
      return Response.status(400).entity(j.writeValueAsString(new HuboError(e.getMessage()))).build();
    }
    finally
    {
      conexion.setAutoCommit(true);
      conexion.close();
    }
  }

  // ------------------ USUARIOS: BORRA ------------------
  @DELETE
  @Path("borra_usuario")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  @Produces(MediaType.APPLICATION_JSON)
  public Response borra(@QueryParam("email") String email,@QueryParam("token") String token) throws Exception
  {
    Connection conexion= pool.getConnection();
    if (!verifica_acceso(conexion,email,token))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Acceso denegado"))).build();

    try
    {
      PreparedStatement stmt_1 = conexion.prepareStatement("SELECT 1 FROM usuarios WHERE email=?");
      try
      {
        stmt_1.setString(1,email);
        ResultSet rs = stmt_1.executeQuery();
        try
        {
          if (!rs.next())
            return Response.status(400).entity(j.writeValueAsString(new HuboError("El email no existe"))).build();
        }
        finally
        { rs.close(); }
      }
      finally
      { stmt_1.close(); }

      conexion.setAutoCommit(false);

      PreparedStatement stmt_2 = conexion.prepareStatement(
        "DELETE FROM fotos_usuarios WHERE id_usuario=(SELECT id_usuario FROM usuarios WHERE email=?)");
      try
      {
        stmt_2.setString(1,email);
        stmt_2.executeUpdate();
      }
      finally
      { stmt_2.close(); }

      PreparedStatement stmt_3 = conexion.prepareStatement("DELETE FROM usuarios WHERE email=?");
      try
      {
        stmt_3.setString(1,email);
        stmt_3.executeUpdate();
      }
      finally
      { stmt_3.close(); }

      conexion.commit();
    }
    catch (Exception e)
    {
      conexion.rollback();
      return Response.status(400).entity(j.writeValueAsString(new HuboError(e.getMessage()))).build();
    }
    finally
    {
      conexion.setAutoCommit(true);
      conexion.close();
    }
    return Response.ok("{\"mensaje\":\"Se borró el usuario\"}").build();
  }

  // ------------------ TAREA 7: ARTÍCULOS ------------------

  @POST
  @Path("alta_articulo")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public Response alta_articulo(@QueryParam("id_usuario") Integer id_usuario,
                                @QueryParam("token") String token,
                                Articulo a) throws Exception
  {
    Connection c = pool.getConnection();
    if (!verifica_acceso(c,id_usuario,token))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Acceso denegado"))).build();

    if (a.nombre == null || a.nombre.isEmpty())
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Nombre requerido"))).build();
    if (a.descripcion == null || a.descripcion.isEmpty())
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Descripción requerida"))).build();
    if (a.precio == null || a.precio <= 0)
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Precio inválido"))).build();
    if (a.cantidad == null || a.cantidad < 0)
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Cantidad inválida"))).build();

    c.setAutoCommit(false);
    try
    {
      int id_articulo = 0;
      PreparedStatement s1 = c.prepareStatement(
        "INSERT INTO stock(id_articulo,nombre,descripcion,precio,cantidad) VALUES(0,?,?,?,?)",
        Statement.RETURN_GENERATED_KEYS);
      try
      {
        s1.setString(1,a.nombre);
        s1.setString(2,a.descripcion);
        s1.setDouble(3,a.precio);
        s1.setInt(4,a.cantidad);
        s1.executeUpdate();
        ResultSet rs = s1.getGeneratedKeys();
        if (rs.next()) id_articulo = rs.getInt(1);
        rs.close();
      }
      finally
      { s1.close(); }

      if (id_articulo == 0)
        throw new Exception("No se obtuvo id_articulo");

      if (a.foto != null)
      {
        PreparedStatement s2 = c.prepareStatement(
          "INSERT INTO fotos_articulos(id_foto,foto,id_articulo) VALUES(0,?,?)");
        try
        {
          s2.setBytes(1,a.foto);
          s2.setInt(2,id_articulo);
          s2.executeUpdate();
        }
        finally
        { s2.close(); }
      }
      c.commit();
      return Response.ok("{\"mensaje\":\"Alta artículo OK\"}").build();
    }
    catch(Exception e)
    {
      c.rollback();
      return Response.status(400).entity(j.writeValueAsString(new HuboError(e.getMessage()))).build();
    }
    finally
    {
      c.setAutoCommit(true);
      c.close();
    }
  }

  @GET
  @Path("consulta_articulos")
  @Produces(MediaType.APPLICATION_JSON)
  public Response consulta_articulos(@QueryParam("palabra") String palabra,
                                     @QueryParam("id_usuario") Integer id_usuario,
                                     @QueryParam("token") String token) throws Exception
  {
    Connection c = pool.getConnection();
    if (!verifica_acceso(c,id_usuario,token))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Acceso denegado"))).build();

    if (palabra == null) palabra = "";
    palabra = "%" + palabra + "%";
    ArrayList<Articulo> lista = new ArrayList<>();

    try
    {
      PreparedStatement s = c.prepareStatement(
        "SELECT a.id_articulo, f.foto, a.nombre, a.descripcion, a.precio " +
        "FROM stock a LEFT OUTER JOIN fotos_articulos f ON a.id_articulo=f.id_articulo " +
        "WHERE a.nombre LIKE ? OR a.descripcion LIKE ?");
      s.setString(1,palabra);
      s.setString(2,palabra);
      ResultSet rs = s.executeQuery();
      while (rs.next())
      {
        Articulo art = new Articulo();
        art.id_articulo = rs.getInt(1);
        art.foto = rs.getBytes(2);
        art.nombre = rs.getString(3);
        art.descripcion = rs.getString(4);
        art.precio = rs.getDouble(5);
        lista.add(art);
      }
      rs.close();
      s.close();
      return Response.ok(j.writeValueAsString(lista)).build();
    }
    catch(Exception e)
    {
      return Response.status(400).entity(j.writeValueAsString(new HuboError(e.getMessage()))).build();
    }
    finally
    { c.close(); }
  }

  // ------------------ TAREA 7: COMPRA / CARRITO ------------------

  @POST
  @Path("compra_articulo")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public Response compra_articulo(@QueryParam("id_usuario") Integer id_usuario,
                                  @QueryParam("token") String token,
                                  Articulo a) throws Exception
  {
    Connection c = pool.getConnection();
    if (!verifica_acceso(c,id_usuario,token))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Acceso denegado"))).build();

    if (a.id_articulo == null || a.cantidad == null || a.cantidad <= 0)
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Datos inválidos"))).build();

    c.setAutoCommit(false);
    try
    {
      int stockActual = 0;
      PreparedStatement s1 = c.prepareStatement("SELECT cantidad FROM stock WHERE id_articulo=? FOR UPDATE");
      s1.setInt(1,a.id_articulo);
      ResultSet rs = s1.executeQuery();
      if (rs.next()) stockActual = rs.getInt(1);
      rs.close();
      s1.close();

      if (a.cantidad > stockActual)
      {
        c.rollback();
        return Response.status(400).entity(j.writeValueAsString(new HuboError("No hay suficientes artículos en stock"))).build();
      }

      PreparedStatement s2 = c.prepareStatement(
        "SELECT cantidad FROM carrito_compra WHERE id_usuario=? AND id_articulo=? FOR UPDATE");
      s2.setInt(1,id_usuario);
      s2.setInt(2,a.id_articulo);
      ResultSet rs2 = s2.executeQuery();
      boolean existe = rs2.next();
      int cantCarrito = existe ? rs2.getInt(1) : 0;
      rs2.close();
      s2.close();

      if (existe)
      {
        PreparedStatement s3 = c.prepareStatement(
          "UPDATE carrito_compra SET cantidad=? WHERE id_usuario=? AND id_articulo=?");
        s3.setInt(1,cantCarrito + a.cantidad);
        s3.setInt(2,id_usuario);
        s3.setInt(3,a.id_articulo);
        s3.executeUpdate();
        s3.close();
      }
      else
      {
        PreparedStatement s4 = c.prepareStatement(
          "INSERT INTO carrito_compra(id_usuario,id_articulo,cantidad) VALUES (?,?,?)");
        s4.setInt(1,id_usuario);
        s4.setInt(2,a.id_articulo);
        s4.setInt(3,a.cantidad);
        s4.executeUpdate();
        s4.close();
      }

      PreparedStatement s5 = c.prepareStatement("UPDATE stock SET cantidad=cantidad-? WHERE id_articulo=?");
      s5.setInt(1,a.cantidad);
      s5.setInt(2,a.id_articulo);
      s5.executeUpdate();
      s5.close();

      c.commit();
      return Response.ok("{\"mensaje\":\"Compra realizada\"}").build();
    }
    catch(Exception e)
    {
      c.rollback();
      return Response.status(400).entity(j.writeValueAsString(new HuboError(e.getMessage()))).build();
    }
    finally
    {
      c.setAutoCommit(true);
      c.close();
    }
  }

  @DELETE
  @Path("elimina_articulo_carrito_compra")
  @Produces(MediaType.APPLICATION_JSON)
  public Response elimina_articulo_carrito_compra(@QueryParam("id_usuario") Integer id_usuario,
                                                  @QueryParam("token") String token,
                                                  @QueryParam("id_articulo") Integer id_articulo) throws Exception
  {
    Connection c = pool.getConnection();
    if (!verifica_acceso(c,id_usuario,token))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Acceso denegado"))).build();

    c.setAutoCommit(false);
    try
    {
      int cant = 0;
      PreparedStatement s1 = c.prepareStatement(
        "SELECT cantidad FROM carrito_compra WHERE id_usuario=? AND id_articulo=? FOR UPDATE");
      s1.setInt(1,id_usuario);
      s1.setInt(2,id_articulo);
      ResultSet rs = s1.executeQuery();
      if (rs.next()) cant = rs.getInt(1);
      rs.close();
      s1.close();

      if (cant == 0)
      {
        c.rollback();
        return Response.status(400).entity(j.writeValueAsString(new HuboError("Artículo no está en el carrito"))).build();
      }

      PreparedStatement s2 = c.prepareStatement("UPDATE stock SET cantidad=cantidad+? WHERE id_articulo=?");
      s2.setInt(1,cant);
      s2.setInt(2,id_articulo);
      s2.executeUpdate();
      s2.close();

      PreparedStatement s3 = c.prepareStatement("DELETE FROM carrito_compra WHERE id_usuario=? AND id_articulo=?");
      s3.setInt(1,id_usuario);
      s3.setInt(2,id_articulo);
      s3.executeUpdate();
      s3.close();

      c.commit();
      return Response.ok("{\"mensaje\":\"Artículo eliminado del carrito\"}").build();
    }
    catch(Exception e)
    {
      c.rollback();
      return Response.status(400).entity(j.writeValueAsString(new HuboError(e.getMessage()))).build();
    }
    finally
    {
      c.setAutoCommit(true);
      c.close();
    }
  }

  @DELETE
  @Path("elimina_carrito_compra")
  @Produces(MediaType.APPLICATION_JSON)
  public Response elimina_carrito_compra(@QueryParam("id_usuario") Integer id_usuario,
                                         @QueryParam("token") String token) throws Exception
  {
    Connection c = pool.getConnection();
    if (!verifica_acceso(c,id_usuario,token))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Acceso denegado"))).build();

    c.setAutoCommit(false);
    try
    {
      PreparedStatement s1 = c.prepareStatement(
        "SELECT id_articulo,cantidad FROM carrito_compra WHERE id_usuario=? FOR UPDATE");
      s1.setInt(1,id_usuario);
      ResultSet rs = s1.executeQuery();
      ArrayList<int[]> items = new ArrayList<>();
      while (rs.next())
      {
        items.add(new int[]{rs.getInt(1), rs.getInt(2)});
      }
      rs.close();
      s1.close();

      for (int[] it : items)
      {
        PreparedStatement s2 = c.prepareStatement("UPDATE stock SET cantidad=cantidad+? WHERE id_articulo=?");
        s2.setInt(1,it[1]);
        s2.setInt(2,it[0]);
        s2.executeUpdate();
        s2.close();
      }

      PreparedStatement s3 = c.prepareStatement("DELETE FROM carrito_compra WHERE id_usuario=?");
      s3.setInt(1,id_usuario);
      s3.executeUpdate();
      s3.close();

      c.commit();
      return Response.ok("{\"mensaje\":\"Carrito eliminado\"}").build();
    }
    catch(Exception e)
    {
      c.rollback();
      return Response.status(400).entity(j.writeValueAsString(new HuboError(e.getMessage()))).build();
    }
    finally
    {
      c.setAutoCommit(true);
      c.close();
    }
  }

  @PUT
  @Path("modifica_carrito_compra")
  @Produces(MediaType.APPLICATION_JSON)
  public Response modifica_carrito_compra(@QueryParam("id_usuario") Integer id_usuario,
                                          @QueryParam("token") String token,
                                          @QueryParam("id_articulo") Integer id_articulo,
                                          @QueryParam("incremento") Integer incremento) throws Exception
  {
    Connection c = pool.getConnection();
    if (!verifica_acceso(c,id_usuario,token))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Acceso denegado"))).build();

    if (incremento == null || (incremento != 1 && incremento != -1))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Incremento inválido"))).build();

    c.setAutoCommit(false);
    try
    {
      PreparedStatement s1 = c.prepareStatement(
        "SELECT cantidad FROM carrito_compra WHERE id_usuario=? AND id_articulo=? FOR UPDATE");
      s1.setInt(1,id_usuario);
      s1.setInt(2,id_articulo);
      ResultSet rs = s1.executeQuery();
      if (!rs.next())
      {
        rs.close();
        s1.close();
        c.rollback();
        return Response.status(400).entity(j.writeValueAsString(new HuboError("Artículo no está en el carrito"))).build();
      }
      int cantCarrito = rs.getInt(1);
      rs.close();
      s1.close();

      PreparedStatement s2 = c.prepareStatement(
        "SELECT cantidad FROM stock WHERE id_articulo=? FOR UPDATE");
      s2.setInt(1,id_articulo);
      ResultSet rs2 = s2.executeQuery();
      if (!rs2.next())
      {
        rs2.close();
        s2.close();
        c.rollback();
        return Response.status(400).entity(j.writeValueAsString(new HuboError("Artículo no existe"))).build();
      }
      int cantStock = rs2.getInt(1);
      rs2.close();
      s2.close();

      if (incremento == 1)
      {
        if (cantStock <= 0)
        {
          c.rollback();
          return Response.status(400).entity(j.writeValueAsString(new HuboError("No hay suficientes artículos en stock"))).build();
        }
        PreparedStatement u1 = c.prepareStatement(
          "UPDATE carrito_compra SET cantidad=cantidad+1 WHERE id_usuario=? AND id_articulo=?");
        u1.setInt(1,id_usuario);
        u1.setInt(2,id_articulo);
        u1.executeUpdate();
        u1.close();

        PreparedStatement u2 = c.prepareStatement("UPDATE stock SET cantidad=cantidad-1 WHERE id_articulo=?");
        u2.setInt(1,id_articulo);
        u2.executeUpdate();
        u2.close();
      }
      else
      {
        if (cantCarrito <= 1)
        {
          c.rollback();
            return Response.status(400).entity(j.writeValueAsString(new HuboError("No hay más artículos en el carrito"))).build();
        }
        PreparedStatement u1 = c.prepareStatement(
          "UPDATE carrito_compra SET cantidad=cantidad-1 WHERE id_usuario=? AND id_articulo=?");
        u1.setInt(1,id_usuario);
        u1.setInt(2,id_articulo);
        u1.executeUpdate();
        u1.close();

        PreparedStatement u2 = c.prepareStatement("UPDATE stock SET cantidad=cantidad+1 WHERE id_articulo=?");
        u2.setInt(1,id_articulo);
        u2.executeUpdate();
        u2.close();
      }

      c.commit();
      return Response.ok("{\"mensaje\":\"Cantidad modificada\"}").build();
    }
    catch(Exception e)
    {
      c.rollback();
      return Response.status(400).entity(j.writeValueAsString(new HuboError(e.getMessage()))).build();
    }
    finally
    {
      c.setAutoCommit(true);
      c.close();
    }
  }

  @GET
  @Path("consulta_carrito_compra")
  @Produces(MediaType.APPLICATION_JSON)
  public Response consulta_carrito_compra(@QueryParam("id_usuario") Integer id_usuario,
                                          @QueryParam("token") String token) throws Exception
  {
    Connection c = pool.getConnection();
    if (!verifica_acceso(c,id_usuario,token))
      return Response.status(400).entity(j.writeValueAsString(new HuboError("Acceso denegado"))).build();

    ArrayList<CarritoItem> lista = new ArrayList<>();
    double total = 0.0;
    try
    {
      PreparedStatement s = c.prepareStatement(
        "SELECT cc.id_articulo, cc.cantidad, s.nombre, s.precio, f.foto " +
        "FROM carrito_compra cc JOIN stock s ON cc.id_articulo=s.id_articulo " +
        "LEFT OUTER JOIN fotos_articulos f ON cc.id_articulo=f.id_articulo " +
        "WHERE cc.id_usuario=?");
      s.setInt(1,id_usuario);
      ResultSet rs = s.executeQuery();
      while (rs.next())
      {
        CarritoItem ci = new CarritoItem();
        ci.id_articulo = rs.getInt(1);
        ci.cantidad = rs.getInt(2);
        ci.nombre = rs.getString(3);
        ci.precio = rs.getDouble(4);
        ci.foto = rs.getBytes(5);
        ci.costo = ci.cantidad * ci.precio;
        total += ci.costo;
        lista.add(ci);
      }
      rs.close();
      s.close();
      return Response.ok("{\"total\":" + total + ",\"items\":" + j.writeValueAsString(lista) + "}").build();
    }
    catch(Exception e)
    {
      return Response.status(400).entity(j.writeValueAsString(new HuboError(e.getMessage()))).build();
    }
    finally
    { c.close(); }
  }
}