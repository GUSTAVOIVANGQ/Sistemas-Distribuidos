/*
  CarritoItem.java
  Representa un ítem dentro del carrito (ensamblado desde varias tablas)
  Tarea 7 - Sistemas Distribuidos
*/

package servicio;

public class CarritoItem
{
  public Integer id_articulo;
  public String nombre;
  public Double precio;
  public Integer cantidad;
  public byte[] foto;
  public Double costo; // cantidad * precio
}