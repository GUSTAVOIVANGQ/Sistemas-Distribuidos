/*
  HuboError.java
  Contenedor de mensajes de error para respuestas JSON
  Carlos Pineda Guerrero, septiembre 2024
*/

package servicio;

public class HuboError
{
  public String message;

  public HuboError(String message)
  {
    this.message = message;
  }
}