/*
  Articulo.java
  Representa un artículo en el stock
  Tarea 7 - Sistemas Distribuidos
*/

package servicio;

public class Articulo
{
  public Integer id_articulo;
  public String nombre;
  public String descripcion;
  public Double precio;
  public Integer cantidad;
  public byte[] foto;
}